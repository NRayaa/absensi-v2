<?php $__env->startSection('crumb', 'Guru'); ?>
<?php $__env->startSection('crumb1', 'Dashboard'); ?>

<?php $__env->startSection('sidebar'); ?>
    <aside id="sidebar" class="sidebar">

        <ul class="sidebar-nav" id="sidebar-nav">

            <li class="nav-item">
                <a class="nav-link collapsed" href="<?php echo e(route('dashboard')); ?>">
                    <i class="bi bi-grid"></i>
                    <span>Dashboard</span>
                </a>
            </li><!-- End Dashboard Nav -->

            <li class="nav-item">
                <a class="nav-link collapsed" href="<?php echo e(route('present.index')); ?>">
                    <i class="bi bi-book"></i>
                    <span>Presensi</span>
                </a>
            </li><!-- End Presensi Nav -->

            <li class="nav-item">
                <a class="nav-link " href="<?php echo e(route('teacher.index')); ?>">
                    <i class="bi bi-person-circle"></i>
                    <span>Guru</span>
                </a>
            </li><!-- End Guru Nav -->

            <li class="nav-item">
                <a class="nav-link collapsed" href="<?php echo e(route('subject.index')); ?>">
                    <i class="bi bi-people"></i>
                    <span>Mapel</span>
                </a>
            </li><!-- End Mapel Nav -->

        </ul>

    </aside><!-- End Sidebar-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">

            <div class="row">
                <div class="col-6">
                    <h5 class="card-title">Data Detail Guru</h5>
                </div>
                <div class="col-6 d-flex justify-content-end align-items-center">
                    <a href="<?php echo e(route('teacher.edit', $teacherDetail->id)); ?>" type="button" class="btn btn-warning"><i class="bi bi-plus me-1"></i> Edit</a>
                </div>
            </div>

            <div class="mb-5">
                <div class="row mb-3">
                    <label for="inputText" class="col-sm-2 col-form-label">Nama Guru</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" disabled value="<?php echo e($teacherDetail->name_teacher); ?>">
                    </div>
                </div>

                <div class="row mb-3">
                    <label for="inputText" class="col-sm-2 col-form-label">Total Hadir</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" disabled value="<?php echo e($present); ?>">
                    </div>
                </div>

                <div class="row mb-3">
                    <label for="inputText" class="col-sm-2 col-form-label">Total Tidak Hadir</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" disabled value="<?php echo e($absent); ?>">
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <h5 class="card-title"></h5>

                    <!-- Table with stripped rows -->
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th scope="col">No</th>
                                
                                <th scope="col">Ke</th>
                                <th scope="col">Tanggal</th>
                                <th scope="col">Kehadiran</th>
                                <th scope="col">Kelas</th>
                                <th scope="col">Mapel</th>
                                <th scope="col">Topik</th>
                                <th scope="col">Total Murid</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $teacherPresent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $present): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                                    
                                    <td><?php echo e($present->meet_p); ?></td>
                                    <td><?php echo e($present->date_p); ?></td>
                                    <td><?php echo e($present->attend_p); ?></td>
                                    <td><?php echo e($present->class_p); ?></td>
                                    <td><?php echo e($present->subject_p); ?></td>
                                    <td><?php echo e($present->topic_p); ?></td>
                                    <td><?php echo e($present->student_p); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <!-- End Table with stripped rows -->

                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\absensi\absensi-v1\resources\views/teacher/show.blade.php ENDPATH**/ ?>