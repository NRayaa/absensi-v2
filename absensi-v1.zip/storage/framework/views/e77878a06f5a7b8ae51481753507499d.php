<?php $__env->startSection('crumb', 'Presensi'); ?>
<?php $__env->startSection('crumb1', 'Dashboard'); ?>

<?php $__env->startSection('sidebar'); ?>
    <aside id="sidebar" class="sidebar">

        <ul class="sidebar-nav" id="sidebar-nav">

            <li class="nav-item">
                <a class="nav-link collapsed" href="<?php echo e(route('dashboard')); ?>">
                    <i class="bi bi-grid"></i>
                    <span>Dashboard</span>
                </a>
            </li><!-- End Dashboard Nav -->

            <li class="nav-item">
                <a class="nav-link " href="<?php echo e(route('present.index')); ?>">
                    <i class="bi bi-book"></i>
                    <span>Presensi</span>
                </a>
            </li><!-- End Presensi Nav -->

            <li class="nav-item">
                <a class="nav-link collapsed" href="<?php echo e(route('teacher.index')); ?>">
                    <i class="bi bi-person-circle"></i>
                    <span>Guru</span>
                </a>
            </li><!-- End Guru Nav -->

            <li class="nav-item">
                <a class="nav-link collapsed" href="<?php echo e(route('subject.index')); ?>">
                    <i class="bi bi-people"></i>
                    <span>Mapel</span>
                </a>
            </li><!-- End Mapel Nav -->

        </ul>

    </aside><!-- End Sidebar-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Form Buat Presensi</h5>

            <!-- General Form Elements -->
            <form action="<?php echo e(route('present.store')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="row mb-3">
                    <label class="col-sm-2 col-form-label">Nama Guru</label>
                    <div class="col-sm-10">
                        <select class="form-select" name="teacher_p" aria-label="Default select example">
                            <?php $__currentLoopData = $dataTeacher; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($teacher->name_teacher); ?>"><?php echo e($teacher->name_teacher); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                <div class="row mb-3">
                    <label class="col-sm-2 col-form-label">Kehadiran</label>
                    <div class="col-sm-10">
                        <select class="form-select" name="attend_p" aria-label="Default select example">
                            <option value="Hadir">Hadir</option>
                            <option value="Tidak hadir">Tidak Hadir</option>
                        </select>
                    </div>
                </div>

                <div class="row mb-3">
                    <label class="col-sm-2 col-form-label">Kelas : </label>
                    <div class="col-sm-10">
                        <select class="form-select" name="class_p" aria-label="Default select example">
                            <option value="Kelas 10 A">Kelas 10 A</option>
                            <option value="Kelas 10 B">Kelas 10 B</option>
                            <option value="Kelas 11 A">Kelas 11 A</option>
                            <option value="Kelas 11 B">Kelas 11 B</option>
                            <option value="Kelas 12 A">Kelas 12 A</option>
                            <option value="Kelas 12 B">Kelas 12 B</option>
                        </select>
                    </div>
                </div>

                <div class="row mb-3">
                    <label for="inputText" class="col-sm-2 col-form-label">Pertemuan Ke</label>
                    <div class="col-sm-10">
                        <input type="number" class="form-control" name="meet_p">
                    </div>
                </div>

                <div class="row mb-3">
                    <label for="inputDate" class="col-sm-2 col-form-label">Tanggal</label>
                    <div class="col-sm-10">
                        <input type="date" class="form-control" name="date_p">
                    </div>
                </div>

                <div class="row mb-3">
                    <label class="col-sm-2 col-form-label">Mata Pelajaran</label>
                    <div class="col-sm-10">
                        <select class="form-select" name="subject_p" aria-label="Default select example">
                            <?php $__currentLoopData = $dataSubject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($subject->name_subject); ?>"><?php echo e($subject->name_subject); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                <div class="row mb-3">
                    <label for="inputText" class="col-sm-2 col-form-label">Topik Pembahasan</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" name="topic_p">
                    </div>
                </div>

                <div class="row mb-3">
                    <label for="inputText" class="col-sm-2 col-form-label">Jumlah Murid Hadir</label>
                    <div class="col-sm-10">
                        <input type="number" class="form-control" name="student_p">
                    </div>
                </div>

                <div class="row mb-3">
                    <div class="col-12 d-flex justify-content-end align-items-center">
                        <button type="submit" class="btn btn-primary">Buat Presensi</button>
                    </div>
                </div>

            </form><!-- End General Form Elements -->

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\absensi\absensi-v1\resources\views/present/create.blade.php ENDPATH**/ ?>