<?php $__env->startSection('crumb', 'Dashboard'); ?>
<?php $__env->startSection('crumb1', 'Dashboard'); ?>

<?php $__env->startSection('sidebar'); ?>
<aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

        <li class="nav-item">
            <a class="nav-link " href="<?php echo e(route('dashboard')); ?>">
                <i class="bi bi-grid"></i>
                <span>Dashboard</span>
            </a>
        </li><!-- End Dashboard Nav -->

        <li class="nav-item">
            <a class="nav-link collapsed" href="<?php echo e(route('present.index')); ?>">
                <i class="bi bi-book"></i>
                <span>Presensi</span>
            </a>
        </li><!-- End Presensi Nav -->

        <li class="nav-item">
            <a class="nav-link " href="<?php echo e(route('teacher.index')); ?>">
                <i class="bi bi-person-circle"></i>
                <span>Guru</span>
            </a>
        </li><!-- End Guru Nav -->

        <li class="nav-item">
            <a class="nav-link collapsed" href="<?php echo e(route('subject.index')); ?>">
                <i class="bi bi-people"></i>
                <span>Mapel</span>
            </a>
        </li><!-- End Mapel Nav -->

    </ul>

</aside><!-- End Sidebar-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    Testing Dashboard
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\absensi\absensi-v1\resources\views/welcome.blade.php ENDPATH**/ ?>